# Getting Started Tutorial
In this quick walkthrough, we preview the high level workflow and interfaces of Snorkel using a canonical machine learning problem: classifying spam. We provide a quick overview of how to use Snorkel's three data operators: labeling functions, transformation functions, and slicing functions.
