# Spouse Tutorial
In this tutorial, we show how Snorkel can be used for Information Extraction. We walk through an example text classification task for information extraction, where we use labeling functions involving keywords and distant supervision.
